#!/usr/bin/env python

from brain_games.welcome_games import welcome_user


def main():
    name = welcome_user()  # приветствуем и вводим имя
    return name  # возвращаем имя


def count_algo_check():
    count_all = 3  # определяем константу количество игр
    return count_all
