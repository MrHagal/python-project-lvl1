#!/usr/bin/env python

from brain_games.games.generation_calc import calc_up
from brain_games.engine_brain import main as main_engine, count_algo_check


def main():
    name = main_engine() # приветствуем и вводим имя
    count_all = count_algo_check() # константа на 3 игры
    calc_up(name, count_all) # получаем текущее значение счетчика





if __name__ == '__main__':
    main()
