#!/usr/bin/env python

def check_calc(name, answer, result, count_all, expression):
    if str(result) == answer:
        expression += 1
        if expression == count_all:
            print(f'Congratulations, {name}!')
            return expression
        else:
            print('Correct!')
            return expression
    else:
        print(f"'{answer}' is wrong answer ;(. "
              f"Correct answer was '{result}'.\n Let's try again, {name}!")
        expression = count_all
        return expression

